module.exports = {
  plugins: {
    tailwindcss: {},
  },
}